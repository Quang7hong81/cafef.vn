#!/bin/bash
 ~/.local/bin/jupyter-notebook
