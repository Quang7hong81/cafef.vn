# tradingstockwithnews
Using news analysis to trading stock
